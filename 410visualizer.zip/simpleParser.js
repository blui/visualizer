
/**
 * Class: simpleParser.js
 * Authors: Tommy Chien, Brian Lui
 * Description: Intermediate setup of a parser for MVP requirements.
 */
 