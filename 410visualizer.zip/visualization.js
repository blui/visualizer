
/**
 * Class: visualization.js
 * Authors: Erik Bengtsson
 * Description: Samples of our desired visualizations with raw data.
 */
 